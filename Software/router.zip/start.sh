#!/usr/bin/env bash
/etc/profile
~/.bash_profile
export DISPLAY=:0
source /home/pi/.bashrc
test=`ps -e | grep router.1`

if [ ! -n "$test" ]
then
echo "null"
cd /home/pi/router/text/
echo "ok"
setsid /home/pi/router/text/router.1 >> /home/pi/router/text/1.log 2>&1 &
echo "ok2"
else
echo 'running'
fi

exit 0
