import requests
import pygame
import sys

url = 'http://169.254.247.232:8081/'
def terminate():
    pygame.quit()
    sys.exit()

def giveReward():
    try:
        req = requests.get(url+'servo2')  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)   

def closeReward():
    try:
        req = requests.get(url+'servo1')  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)  

def givePunish():
    try:
        req = requests.get(url+'punish')  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)   

def closePunish():
    try:
        req = requests.get(url+'unpunish')  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)  
