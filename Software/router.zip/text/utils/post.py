import requests

url = 'http://169.254.247.232:8080/bird'


def postMessage(data):
    try:
        req = requests.post(url, data)  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)


fs = 'asdfasdfs'
def ppp():
    print(fs)