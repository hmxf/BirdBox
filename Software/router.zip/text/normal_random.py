#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import sys
import time
import os
import argparse
import pygame
import requests
from pygame.locals import *
from utils import *
import random

class GAME:
    def getList(self,keyword):
        path = sys.path[0]
        a = os.listdir(path+'/src/')
        group = []
        lenth = len(keyword)
        if keyword=='a':
            low = self.MusicTA[0]
            high = self.MusicTA[1]
        elif keyword == 'b':
            low = self.MusicTB[0]
            high = self.MusicTB[1]
        else:
            terminate()
        
        for song in a :
            if len(song)<5:
                print('error1:'+song+' is not available!Please give a wav media!')
                continue
            if song[-3:]  != 'wav':
                print('error2:'+song+' is not available!Please give a wav media!')
                continue
            if not song[lenth:-4].isdigit():
                print('error3:'+song+' is not a normal name, please rename it as '+keyword+' + number + .wav , like: '+keyword+'1.wav !')
                continue
            if int(song[lenth:-4])<low or int(song[lenth:-4])>high:
                print('error5:'+song+' is not in the training group!')
                continue
            if song[:lenth] == keyword:
                group.append(song)
            else:
                print('error4:'+song+' is not in this group!')

        print(group)
        return group

    def sound(self):
        if self.soundListA == [] and self.soundListB ==[]:
            self.soundListA = self.getList('a')
            self.soundListB = self.getList('b')
            data={
                    'time':time.time(),
                    'action':'play music group:\n A: '.join(self.soundListA)+'\n B: '.join(self.soundListB)
            }
            post.postMessage(data)

        if self.soundListA == []:
            mode = 2
        elif self.soundListB == []:
            mode = 1
        else:
            if random.randint(1,100)<51:
                mode = 1
            else:
                mode = 2

        if mode == 1 :
            soundList = self.soundListA
        else:
            soundList = self.soundListB
        lenth = len(soundList)
        music_num = random.randint(1,lenth)
        music = soundList[music_num-1]
        sound = pygame.mixer.Sound(sys.path[0]+"/src/"+music)
        musicTime=int(pygame.mixer.Sound.get_length(sound))+1
        print((sys.path[0]+"/src/"+music))
        print(music)
        sound.set_volume(0.9)
        sound.play()
        pygame.time.wait(1000*musicTime)
        sound.stop()
        global MUSIC_UP
        my_event = pygame.event.Event(MUSIC_UP, {"message": music})
        pygame.event.post(my_event)
        print('listA:',self.soundListA)
        print('listB:',self.soundListB)
        return mode
        
    def changeStatus(self,button):
        if self.status==0 and button == 2:
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG2 ,RADIUS)
            pygame.display.update()
            self.status= self.sound()
            pygame.draw.circle(DISPLAYSURF,RED,POS_IMG1 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,RED,POS_IMG3 ,RADIUS)
            pygame.display.update()
            return
        if self.status==1 and button == 1:

            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG1 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG2 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG3 ,RADIUS)
            pygame.display.update()
            self.reward()
            self.status=0
            pygame.time.wait(1000*self.DelayTime)
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
            pygame.display.update()
            return
        
        if self.status==2 and button == 3:

            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG1 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG2 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG3 ,RADIUS)
            pygame.display.update()
            self.reward()       
            self.status=0
            pygame.time.wait(1000*self.DelayTime)
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
            pygame.display.update()
            return

        if self.status==1 and button == 3:

            pygame.draw.rect(DISPLAYSURF,BLACK,[0,0,1024,600])
            pygame.display.update()
            self.punish()
            self.status=0
            DISPLAYSURF.fill(WHITE, rect=None, special_flags=0)
            pygame.display.update()
            pygame.time.wait(1000*self.DelayTime)
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
            pygame.display.update()
            return
        
        if self.status==2 and button == 1:

            pygame.draw.rect(DISPLAYSURF,BLACK,[0,0,1024,600])
            pygame.display.update()
            self.punish()       
            self.status=0
            DISPLAYSURF.fill(WHITE, rect=None, special_flags=0)
            pygame.display.update()
            pygame.time.wait(1000*self.DelayTime)
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
            pygame.display.update()
            return

        if button == 99:
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG1 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG3 ,RADIUS)
            pygame.display.update()       
            self.status=0
            pygame.time.wait(1000*self.DelayTime)
            return

    def touch(self,pos):
        x, y = pos
        data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch Screen'
        }
 
        if isInside(POS_IMG1,pos,RADIUS):
            print('Touch The Left Button')
            data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch The Left Button'
            }
            post.postMessage(data)
            self.changeStatus(1)
        elif isInside(POS_IMG2,pos,RADIUS):
            print('Touch The Middle Button')
            data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch The Middle Button'
            }
            post.postMessage(data)
            self.changeStatus(2)
        elif isInside(POS_IMG3,pos,RADIUS):
            print('Touch The Right Button')
            data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch The Right Button'
            }
            post.postMessage(data)
            self.changeStatus(3)
        else:
            post.postMessage(data)

        clean()

    def __init__(self,args):
        self.status = 0
        self.RewardTime = args.reward
        self.PunishTime = args.punish
        self.DelayTime = args.delay
        self.MusicTA = args.selecta
        self.MusicTB = args.selectb
        self.soundListA = []
        self.soundListB = []
    
    
    def reward(self):
        data={
            'time':time.time(),
            'action':'Give Reward!'
        }
        post.postMessage(data)
        control.giveReward()
        pygame.time.wait(1000*self.RewardTime)
        control.closeReward()

    def punish(self):
        data={
            'time':time.time(),
            'action':'Give Punish!'
        }
        post.postMessage(data)
        control.givePunish()
        pygame.time.wait(1000*self.RewardTime)
        control.closePunish()


# 三个参数分别为图片圆心，当前位置，半径
def isInside(pos,realPos,radius):
    x,y = pos
    x1,y1 = realPos
    result=(x1-x)**2+(y1-y)**2
    if (x1-x)**2+(y1-y)**2<radius**2:
        return True
    else:
        return False

def clean():
    event = pygame.event.clear()
    print(event)

def terminate():
    data={ 
        'time':time.time(),
        'action':'STOP script normal_circle.py!'
    }
    post.postMessage(data)
    pygame.quit()
    sys.exit()

def main():
    parser = argparse.ArgumentParser(description='The Basic Trainning!',formatter_class=argparse.MetavarTypeHelpFormatter)
    parser.add_argument('-r','--reward',type=int,default='5',help='set the rewarding time.')
    parser.add_argument('-p','--punish',type=int,default='5',help='set the punishing time.')
    parser.add_argument('-d','--delay',type=int,default='2',help='set the delay time.')
    # parser.add_argument('-sa','--selecta',type=str,default='a1',help='set the music for the left side,please type the music name without Suffix,and only support .wav format.')
    # parser.add_argument('-sb','--selectb',type=str,default='b1',help='set the music for the right side,please type the music name without Suffix,and only support .wav format.')
    parser.add_argument('-sa','--selecta',type=int,help='set the music for the left side,please type the music name without Suffix,and only support .wav format.',nargs=2)
    parser.add_argument('-sb','--selectb',type=int,help='set the music for the right side,please type the music name without Suffix,and only support .wav format.',nargs=2)
    args = parser.parse_args()
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption('Bird Gaming')
    obj = GAME(args)

    fps = 15
    fcclock = pygame.time.Clock()

    pygame.display.update()
    img_flag =0
    timeout_flag = 0

    pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
    pygame.display.update()

    pygame.mouse.set_cursor((8,8),(0,0),(0,0,0,0,0,0,0,0),(0,0,0,0,0,0,0,0))


    data={ 
        'time':time.time(),
        'action':'START script normal_circle.py!'
    }
    post.postMessage(data)

    while True:  # main game loop

        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    terminate()
            elif event.type == MOUSEBUTTONUP:
                obj.touch(event.pos)
            elif event.type == MUSIC_UP:
                timeout_flag = 1

        if obj.status == 0:
            timeout_flag = 0
        elif obj.status ==1:
            timeout_flag = timeout_flag +1
        else:
            timeout_flag = timeout_flag +1

        if timeout_flag == FPS*10:
            obj.changeStatus(99)
            timeout_flag = 0
            
        img_flag= (img_flag+1)%fps
        
        fcclock.tick(fps)



BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

POS_IMG1 = (162,300)
POS_IMG2 = (512,300)
POS_IMG3 = (862,300)
RADIUS = 100

FPS = 15



# draw on the surface object
DISPLAYSURF = pygame.display.set_mode((1024, 600),FULLSCREEN) 
DISPLAYSURF.fill(WHITE, rect=None, special_flags=0)

MUSIC_UP = pygame.USEREVENT + 1

if __name__ == '__main__':
    main()

## status 0-常规  1=播放A 2-播放B 3-超时处理