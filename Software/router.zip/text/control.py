#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import sys
import time

import pygame
import requests
from pygame.locals import *
import random

def status_change(touchSpace):
    global STATUS
    global MUSIC
    statusCurrent = STATUS
    print("status_change:",touchSpace)
    url = 'http://192.168.0.108:8080/bird'
    data={
        'time':time.time(),
        'action':'Status Change'
    }

    if touchSpace == 97:
        data={
            'time':time.time(),
            'action':'Status Change to Mode 1'
        }
        postMessage(url,data)
        pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG2 ,RADIUS)
        pygame.display.update()
        pygame.time.wait(250)
        pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
        pygame.display.update()    
        return
    if touchSpace == 2:
        pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG2 ,RADIUS)
        pygame.display.update()
        data={
            'time':time.time(),
            'action':'Rewarding Time'
        }
        postMessage(url,data)
        reward()
        pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
        pygame.display.update()
        return
    
    if touchSpace == 99:
        punish()
        data={
                'time':time.time(),
                'action':'Status Change to Mode 0'
            }
        postMessage(url,data)
        return

def reward():
    url = 'http://192.168.0.108:8080/bird'
    data={
            'time':time.time(),
            'action':'Give rewards'
        }
    postMessage(url,data)
    getRewards('http://192.168.0.108:8081/servo2')
    pygame.time.wait(3000)
    closeRewards('http://192.168.0.108:8081/servo1')
    print('rewarding time')


# 奖励程序
def touch_base(pos):##
    x, y = pos
    url = 'http://192.168.0.108:8080/bird'
    data={
            'time':time.time(),
            'x':x,
            'y':y,
            'action':'Touch Screen'
        }

    if x > 412 and x < 612 and y > 200 and y < 400:
        status_change(2)

    postMessage(url,data)


def terminate():
    pygame.quit()
    sys.exit()

def punish():

    url='http://192.168.0.108:8080/bird'
    data={
            'time':time.time(),
            'action':'Music Down'
        }
    postMessage(url,data)


def postMessage(url,data):
    try:
        req = requests.post(url, data)  # 发送post请求，第一个参数是URL，第二个参数是请求数据
        print(req)
    except Exception as e:
        print(e)
def getRewards(url):
    try:
        req=requests.get(url)
    except Exception as e:
        print(e)

def closeRewards(url):
    try:
        req=requests.get(url)
    except Exception as e:
        print(e)

def main():
 
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption('Drawing')

    fcclock = pygame.time.Clock()
    pygame.draw.circle(DISPLAYSURF,BLACK,POS_IMG2 ,RADIUS+3,3)
    pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG2 ,RADIUS)
    pygame.display.update()
    global MUSIC
    global STATUS
    while True:  # main game loop
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    terminate()
                elif event.key == K_SPACE:
                    status_change(97)
                    MUSIC = 1
            elif event.type == MOUSEBUTTONUP:
                touch_base(event.pos)

        if MUSIC != 0:
            MUSIC = MUSIC+1
        if MUSIC == REACTIONTIME*1000:
            STATUS = 0
            MUSIC = 0
        fcclock.tick(FPS)


BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
DISPLAYSURF = pygame.display.set_mode((1024, 600),FULLSCREEN) 
RADIUS = 100
POS_IMG1 = (162,300)
POS_IMG2 = (512,300)
POS_IMG3 = (862,300)
FPS = 15
STATUS=0
MUSIC = 0


# 超时时间
REACTIONTIME = 15
# define event 
AAA = pygame.USEREVENT + 2
# draw on the surface object
DISPLAYSURF.fill(WHITE, rect=None, special_flags=0)

if __name__ == '__main__':
    main()

