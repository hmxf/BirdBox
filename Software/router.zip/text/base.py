#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import sys
import time
import argparse
import pygame
import requests
from pygame.locals import *
from utils import *


class GAME:
    def bar(self):
        pass

    def touch(self,pos):


        x, y = pos
        data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch Screen'
        }
 
        if isInside(POS_IMG,pos,RADIUS):
            print(1)
            data={
                'time':time.time(),
                'x':x,
                'y':y,
                'action':'Touch The Button'
            }
            post.postMessage(data)
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG ,100)
            pygame.display.update()
            control.giveReward()
            pygame.time.wait(1000*self.RewardTime)
            control.closeReward()
            pygame.time.wait(1000*self.DelayTime)
        # data = {'time': time,  'pos_x': x, 'pos_y': y,'status':status,'action':action}
        else:
            post.postMessage(data)
        
        clean()

    def __init__(self,args):
        self.status = 0
        self.RewardTime = args.reward
        self.PunishTime = args.punish
        self.DelayTime = args.delay

# 三个参数分别为图片圆心，当前位置，半径
def isInside(pos,realPos,radius):
    x,y = pos
    x1,y1 = realPos
    result=(x1-x)**2+(y1-y)**2

    if (x1-x)**2+(y1-y)**2<radius**2:
        return True
    else:
        return False

def clean():
    event = pygame.event.clear()
    print(event)

def terminate():
    data={ 
        'time':time.time(),
        'action':'STOP script base.py!'
    }
    post.postMessage(data)
    pygame.quit()
    sys.exit()

def main():
    parser = argparse.ArgumentParser(description='The Basic Trainning!',formatter_class=argparse.MetavarTypeHelpFormatter)
    parser.add_argument('-r','--reward',type=int,default='5',help='set the rewarding time.')
    parser.add_argument('-p','--punish',type=int,default='5',help='set the punishing time.')
    parser.add_argument('-d','--delay',type=int,default='2',help='set the delay time.')
    parser.add_argument('-sa','--selecta',type=str,default='a1',help='set the music for the left side,please type the music name without Suffix,and only support .wav format.')
    parser.add_argument('-sb','--selectb',type=str,default='b1',help='set the music for the right side,please type the music name without Suffix,and only support .wav format.')
    args = parser.parse_args()
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption('Bird Gaming')
    obj = GAME(args)
    fcclock = pygame.time.Clock()

    pygame.display.update()
    img_flag =0
    fps = FPS
    pygame.mouse.set_cursor((8,8),(0,0),(0,0,0,0,0,0,0,0),(0,0,0,0,0,0,0,0))

    data={ 
        'time':time.time(),
        'action':'Start script base.py!'
    }
    post.postMessage(data)

    while True:  # main game loop

        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    terminate()
            elif event.type == MOUSEBUTTONUP:
                obj.touch(event.pos)

# 闪烁##
        if img_flag%fps==0 or img_flag%fps==int(fps/2):
            pygame.draw.circle(DISPLAYSURF,GREEN,POS_IMG ,RADIUS)
            pygame.display.update()
        elif img_flag%fps==int(fps/4) or img_flag%fps==int(3*fps/4):
            # DISPLAYSURF.fill(WHITE,(POS_IMG,testingSize))
            pygame.draw.circle(DISPLAYSURF,WHITE,POS_IMG ,RADIUS)
            pygame.display.update()

        img_flag= (img_flag+1)%fps
        # print(img_flag)
        fcclock.tick(FPS)


BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

POS_IMG = (512,300)
RADIUS = 100
RewardTime = 3

FPS = 15

# draw on the surface object
DISPLAYSURF = pygame.display.set_mode((1024, 600),FULLSCREEN) 
DISPLAYSURF.fill(WHITE, rect=None, special_flags=0)

if __name__ == '__main__':
    main()
