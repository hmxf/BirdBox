/home/pi/box/box/main>>/home/pi/box/log/1.log &
/home/pi/box/bird/test_router>>/home/pi/box/log/2.log &
exit 1
