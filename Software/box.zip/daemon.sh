#!/bin/bash

test=`curl http://localhost:8080/ping`
router=`curl http://localhost:8081/ping`
message={\"message\":\"pong\"}
echo $message
if [[ $test = $message ]] && [[ $router = $message ]]
then
echo "fa"
else
echo 'no'
/home/pi/box/start.sh>>/home/pi/box/log/.log
fi

exit 0
